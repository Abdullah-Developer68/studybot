const ensureClient = (supabaseClient) => {
  if (!supabaseClient?.auth) {
    throw new Error("Supabase client is required");
  }
};

const signUp = async (supabaseClient, email, password) => {
  ensureClient(supabaseClient);
  const { data, error } = await supabaseClient.auth.signUp({
    email,
    password,
  });

  if (error) {
    throw new Error(error.message);
  }
  return data;
};

const signIn = async (supabaseClient, email, password) => {
  ensureClient(supabaseClient);
  const { data, error } = await supabaseClient.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    throw new Error(error.message);
  }
  return data;
};

const signOut = async (supabaseClient) => {
  ensureClient(supabaseClient);
  const { error } = await supabaseClient.auth.signOut();
  if (error) {
    throw new Error(error.message);
  }
};

const signInWithOAuth = async (supabaseClient, provider, redirectTo = null) => {
  ensureClient(supabaseClient);
  const options = {};

  if (redirectTo) {
    options.redirectTo = redirectTo;
  }

  const { data, error } = await supabaseClient.auth.signInWithOAuth({
    provider,
    options,
  });

  if (error) {
    throw new Error(error.message);
  }

  return data;
};

const getUserFromSession = async (supabaseClient) => {
  try {
    ensureClient(supabaseClient);

    const { data: sessionResult, error: sessionError } =
      await supabaseClient.auth.getSession();

    if (sessionError) {
      return {
        user: null,
        session: null,
        error: sessionError.message,
      };
    }

    const session = sessionResult?.session ?? null;

    if (!session) {
      return {
        user: null,
        session: null,
        error: null,
      };
    }

    const { data: userResult, error: userError } =
      await supabaseClient.auth.getUser();

    if (userError) {
      return {
        user: null,
        session,
        error: userError.message,
      };
    }

    return {
      user: userResult?.user ?? null,
      session,
      error: null,
    };
  } catch (error) {
    return {
      user: null,
      session: null,
      error: error?.message || "Failed to resolve user from session",
    };
  }
};

const onAuthStateChange = (supabaseClient, callback) => {
  ensureClient(supabaseClient);
  const {
    data: { subscription },
  } = supabaseClient.auth.onAuthStateChange((event, session) => {
    callback(event, session);
  });

  return subscription;
};

export {
  signUp,
  signIn,
  signOut,
  signInWithOAuth,
  getUserFromSession,
  onAuthStateChange,
};
